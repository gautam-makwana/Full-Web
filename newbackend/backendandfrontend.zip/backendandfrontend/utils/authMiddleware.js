const jwt = require("jsonwebtoken");
const JWT_SECRET = process.env.JWT_SECRET || "dev_jwt_secret";

// ---------------- Express middleware ----------------
const authMiddleware = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith("Bearer ")) {
      return res.status(401).json({ error: "No token provided" });
    }

    const token = authHeader.split(" ")[1];
    jwt.verify(token, JWT_SECRET, (err, decoded) => {
      if (err) {
        console.error("Auth error:", err.message);
        return res.status(401).json({ error: "Invalid or expired token" });
      }
      req.user = decoded; // attach user info
      next();
    });
  } catch (err) {
    console.error("Unexpected auth error:", err);
    res.status(500).json({ error: "Server error during authentication" });
  }
};

// ---------------- Socket.IO middleware ----------------
const verifyTokenSocket = (socket) => {
  return new Promise((resolve, reject) => {
    const token = socket.handshake.auth?.token || socket.handshake.query?.token;

    if (!token) return reject(new Error("No token provided"));

    jwt.verify(token, JWT_SECRET, (err, decoded) => {
      if (err) {
        console.error("Socket auth error:", err.message);
        return reject(new Error("Invalid or expired token"));
      }
      socket.user = decoded; // attach user info
      resolve();
    });
  });
};

module.exports = { authMiddleware, verifyTokenSocket };
