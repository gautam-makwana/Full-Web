const express = require("express");
const router = express.Router();
const nearbyController = require("../controllers/nearby_recommendations");

// GET nearby recommendations by lat/lng
router.get("/", nearbyController.getNearby);

module.exports = router;
