// backend/routes/transport.js
const express = require("express");
const router = express.Router();
const { getFlights, getTrains, getBuses } = require("../controllers/transport_controller");
const { verifyToken } = require("../utils/authMiddleware");

router.get("/flights", verifyToken, getFlights);
router.get("/trains", verifyToken, getTrains);
router.get("/buses", verifyToken, getBuses);

module.exports = router;
