const express = require("express");
const router = express.Router();
const aiController = require("../controllers/ai_chatbot_for_local_assistance");

// POST user message → Gemini AI response
router.post("/", aiController.getAIResponse);

module.exports = router;
