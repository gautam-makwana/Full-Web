const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const { authMiddleware } = require("../utils/authMiddleware");

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || "dev_jwt_secret"; // ✅ ensure same secret everywhere

// ---------------- Register ----------------
router.post("/register", async (req, res) => {
  const { name, email, password } = req.body;

  try {
    if (!name || !email || !password) {
      return res.status(400).json({ error: "Name, email, and password are required" });
    }

    const existing = await User.findOne({ email });
    if (existing) return res.status(409).json({ error: "Email already registered" });

    const hash = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, passwordHash: hash });

    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: "30d" });

    res.status(201).json({
      token,
      user: { id: user._id, name: user.name, email: user.email, travelType: user.travelType },
    });
  } catch (err) {
    console.error("Register error:", err);
    res.status(500).json({ error: "Server error during registration" });
  }
});

// ---------------- Login ----------------
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    if (!email || !password) {
      return res.status(400).json({ error: "Email and password required" });
    }

    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ error: "Invalid credentials" });

    const validPassword = await bcrypt.compare(password, user.passwordHash);
    if (!validPassword) return res.status(401).json({ error: "Invalid credentials" });

    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: "30d" });

    res.json({
      token,
      user: { id: user._id, name: user.name, email: user.email, travelType: user.travelType },
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Server error during login" });
  }
});

// ---------------- Current user ----------------
router.get("/me", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-passwordHash");
    if (!user) return res.status(404).json({ error: "User not found" });

    res.json({ user });
  } catch (err) {
    console.error("Auth check error:", err);
    res.status(401).json({ error: "Invalid or expired token" });
  }
});

// ---------------- Update travel type ----------------
router.put("/travel-type", authMiddleware, async (req, res) => {
  try {
    const { travelType } = req.body;

    if (!["solo", "group"].includes(travelType)) {
      return res.status(400).json({ error: "Invalid travel type" });
    }

    const user = await User.findByIdAndUpdate(
      req.user.id,
      { travelType },
      { new: true }
    ).select("-passwordHash");

    res.json({ success: true, user });
  } catch (err) {
    console.error("Update travel type error:", err);
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
