// backend/routes/trips.js
const express = require("express");
const router = express.Router();
const { getTripSummary } = require("../controllers/tripController");
const { verifyToken } = require("../utils/authMiddleware");

router.get("/summary", verifyToken, getTripSummary);

module.exports = router;
