const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const { authMiddleware } = require("../utils/authMiddleware");
const Journal = require("../models/Journal");

const router = express.Router();

// ---------------- Multer Storage ----------------
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, "../uploads/journal");
    fs.mkdirSync(uploadPath, { recursive: true });
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${file.originalname}`;
    cb(null, uniqueName);
  },
});
const upload = multer({ storage });

// ---------------- GET all entries ----------------
router.get("/", authMiddleware, async (req, res) => {
  try {
    const entries = await Journal.find({ userId: req.user.id }).sort({
      createdAt: -1,
    });
    res.json({ entries });
  } catch (err) {
    console.error("Fetch error:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// ---------------- POST new entry ----------------
router.post("/", authMiddleware, upload.array("photos", 10), async (req, res) => {
  try {
    const { title, content } = req.body;

    const photos =
      req.files?.map((file) => ({
        // ✅ build absolute URL using server host
        url: `${req.protocol}://${req.get("host")}/uploads/journal/${file.filename}`,
      })) || [];

    const newEntry = new Journal({
      userId: req.user.id, // ✅ correct field
      title,
      content,
      photos,
    });

    await newEntry.save();
    res.json({ entry: newEntry });
  } catch (err) {
    console.error("Create error:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// ---------------- DELETE entry ----------------
router.delete("/:id", authMiddleware, async (req, res) => {
  try {
    const entry = await Journal.findOne({
      _id: req.params.id,
      userId: req.user.id,
    });

    if (!entry) {
      return res.status(404).json({ error: "Entry not found" });
    }

    await entry.deleteOne();
    res.json({ success: true });
  } catch (err) {
    console.error("Delete error:", err);
    res.status(500).json({ error: "Server error while deleting entry" });
  }
});

module.exports = router;
