const express = require("express");
const router = express.Router();
const travelTypeController = require("../controllers/travel_type_selection");

// GET available travel types
router.get("/", travelTypeController.getTravelTypes);

module.exports = router;
