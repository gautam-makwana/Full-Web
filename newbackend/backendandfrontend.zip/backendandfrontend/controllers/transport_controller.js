// backend/controllers/transport_controller.js
const { getFlights, getTrains, getBuses } = require("../services/transport_service");

exports.getFlights = async (req, res) => {
  const { from, to, date } = req.query;
  const results = await getFlights(from, to, date);
  res.json({ results });
};

exports.getTrains = async (req, res) => {
  const { from, to, date } = req.query;
  const results = await getTrains(from, to, date);
  res.json({ results });
};

exports.getBuses = async (req, res) => {
  const { from, to, date } = req.query;
  const results = await getBuses(from, to, date);
  res.json({ results });
};
