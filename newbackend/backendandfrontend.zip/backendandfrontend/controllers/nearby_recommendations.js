// backend/controllers/nearby_recommendations.js
const { getNearbyPlaces } = require("../services/google_places");

exports.getNearbyRecommendations = async (req, res) => {
  try {
    const { lat, lon, type } = req.query;
    if (!lat || !lon) return res.status(400).json({ error: "lat & lon required" });

    const places = await getNearbyPlaces(lat, lon, type || "tourist_attraction");
    res.json({ results: places });
  } catch (err) {
    console.error("Nearby error:", err.message);
    res.status(500).json({ error: "Failed to fetch nearby places" });
  }
};
