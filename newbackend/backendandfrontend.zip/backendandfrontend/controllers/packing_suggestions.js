// backend/controllers/packing_suggestions.js
const { getWeather } = require("../services/weather_service");

exports.getPackingSuggestions = async (req, res) => {
  try {
    const { city } = req.query;
    if (!city) return res.status(400).json({ error: "City is required" });

    const weather = await getWeather(city);
    const suggestions = [];

    // Base essentials
    suggestions.push("Passport/ID", "Travel tickets", "Wallet", "Phone & Charger");

    if (weather?.main?.temp < 15) {
      suggestions.push("Warm Jacket", "Woolen Cap", "Gloves");
    } else if (weather?.main?.temp > 30) {
      suggestions.push("Light Cotton Clothes", "Sunscreen", "Sunglasses", "Hat");
    }

    if (weather?.weather?.[0]?.main === "Rain") {
      suggestions.push("Umbrella", "Raincoat", "Waterproof Shoes");
    }

    // Activity-specific
    if (req.query.mood === "adventure") {
      suggestions.push("Hiking Boots", "Trekking Pole", "First Aid Kit");
    }
    if (req.query.mood === "beach") {
      suggestions.push("Swimwear", "Flip Flops", "Beach Towel");
    }

    res.json({ city, weather, suggestions });
  } catch (err) {
    console.error("Packing API error:", err.message);
    res.status(500).json({ error: "Failed to fetch packing suggestions" });
  }
};
