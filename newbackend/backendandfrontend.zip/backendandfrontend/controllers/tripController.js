// backend/controllers/tripController.js
const Trip = require("../models/Trip");

exports.getTripSummary = async (req, res) => {
  try {
    const trip = await Trip.findOne({ user: req.user.id }).populate("members");
    if (!trip) return res.status(404).json({ msg: "No trip found" });
    res.json(trip);
  } catch (err) {
    console.error("Trip summary error:", err.message);
    res.status(500).json({ error: "Failed to fetch trip summary" });
  }
};
