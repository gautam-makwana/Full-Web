// backend/controllers/travel_type_selection.js

/**
 * Controller for Travel Type Selection
 * Returns a static list of travel categories
 */
exports.getTravelTypes = async (req, res) => {
  try {
    const travelTypes = [
      { id: 1, name: "Adventure", desc: "Trekking, rafting, camping, thrill-seeking" },
      { id: 2, name: "Relaxation", desc: "Beach holidays, wellness retreats, spa" },
      { id: 3, name: "Cultural", desc: "Temples, heritage, museums, local traditions" },
      { id: 4, name: "Nature", desc: "Hill stations, forests, lakes, wildlife" },
      { id: 5, name: "Luxury", desc: "Resorts, fine dining, cruises, premium experiences" },
    ];
    res.json({ success: true, data: travelTypes });
  } catch (err) {
    console.error("❌ Error fetching travel types:", err);
    res.status(500).json({ success: false, error: "Failed to fetch travel types" });
  }
};
