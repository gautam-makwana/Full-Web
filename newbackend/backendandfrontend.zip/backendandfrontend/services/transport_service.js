// backend/services/transport_service.js
const axios = require("axios");

const AVIATIONSTACK_KEY = process.env.AVIATIONSTACK_API_KEY; // flights
const REDBUS_API_KEY = process.env.REDBUS_API_KEY; // if you get real API access
const RAIL_API_URL = process.env.RAIL_API_URL || "http://localhost:5000"; // your indian-rail-api service

// Fetch flights
async function getFlights(from, to, date) {
  try {
    const res = await axios.get(
      `http://api.aviationstack.com/v1/flights?access_key=${AVIATIONSTACK_KEY}&dep_iata=${from}&arr_iata=${to}&flight_date=${date}`
    );
    return (
      res.data.data?.map((f) => ({
        airline: f.airline?.name,
        flightNumber: f.flight?.iata,
        from: f.departure?.airport,
        to: f.arrival?.airport,
        departure: f.departure?.estimated,
        arrival: f.arrival?.estimated,
        status: f.flight_status,
        price: Math.floor(Math.random() * 5000) + 3000, // mock price
        duration: "2h 30m", // AviationStack free tier doesn’t give duration
      })) || []
    );
  } catch (err) {
    console.error("Flight API error:", err.message);
    return [];
  }
}

// Fetch trains
async function getTrains(from, to, date) {
  try {
    const res = await axios.get(`${RAIL_API_URL}/getTrains`, {
      params: { from, to, date },
    });
    return res.data.trains || [];
  } catch (err) {
    console.error("Train API error:", err.message);
    return [];
  }
}

// Fetch buses
async function getBuses(from, to, date) {
  try {
    // Replace with real Redbus API if available
    return [
      {
        provider: "KSRTC",
        from,
        to,
        departure: `${date}T08:00:00Z`,
        arrival: `${date}T16:00:00Z`,
        duration: "8h",
        price: 1200,
        status: "active",
      },
      {
        provider: "VRL Travels",
        from,
        to,
        departure: `${date}T22:00:00Z`,
        arrival: `${date}T06:00:00Z`,
        duration: "8h",
        price: 1400,
        status: "active",
      },
    ];
  } catch (err) {
    console.error("Bus API error:", err.message);
    return [];
  }
}

module.exports = { getFlights, getTrains, getBuses };
