// backend/services/google_places.js
const axios = require("axios");
const GOOGLE_KEY = process.env.GOOGLE_MAPS_API_KEY;

async function getNearbyPlaces(lat, lon, type) {
  try {
    const url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${lat},${lon}&radius=5000&type=${type}&key=${GOOGLE_KEY}`;
    const res = await axios.get(url);
    return res.data.results.map((p) => ({
      name: p.name,
      address: p.vicinity,
      rating: p.rating,
      location: p.geometry.location,
    }));
  } catch (err) {
    console.error("Google Places error:", err.message);
    return [];
  }
}

module.exports = { getNearbyPlaces };
