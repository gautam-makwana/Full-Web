// backend/services/ai_client.js
const { GoogleGenerativeAI } = require("@google/generative-ai");

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

async function chatWithGemini(userMessage) {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    const result = await model.generateContent(userMessage);
    return result.response.text();
  } catch (err) {
    console.error("Gemini API error:", err.message);
    return "Sorry, I couldn’t process your request.";
  }
}

module.exports = { chatWithGemini };
