// frontend/src/components/LanguageTranslator.jsx
import React, { useState } from "react";
import axios from "axios";

export default function LanguageTranslator() {
  const [text, setText] = useState("");
  const [lang, setLang] = useState("hi");
  const [translated, setTranslated] = useState("");

  const translate = async () => {
    try {
      const res = await axios.post(`/api/language/translate`, { text, targetLang: lang });
      setTranslated(res.data.translated);
    } catch (err) {
      console.error("Translation error:", err);
      setTranslated("");
    }
  };

  return (
    <div className="p-4 bg-white/10 rounded-2xl shadow-lg text-gray-200">
      <h2 className="text-xl font-semibold mb-3">🌐 Language Translator</h2>
      <textarea
        className="w-full p-2 rounded bg-black/30 mb-2"
        rows="3"
        placeholder="Enter text"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <div className="flex space-x-2 mb-3">
        <input
          value={lang}
          onChange={(e) => setLang(e.target.value)}
          className="px-2 py-1 rounded bg-black/30"
          placeholder="Target language (e.g., hi, fr)"
        />
        <button
          onClick={translate}
          className="px-4 py-2 bg-pink-500 text-white rounded hover:bg-pink-600 transition"
        >
          Translate
        </button>
      </div>
      {translated && (
        <p className="bg-black/30 p-2 rounded">Translation: {translated}</p>
      )}
    </div>
  );
}
