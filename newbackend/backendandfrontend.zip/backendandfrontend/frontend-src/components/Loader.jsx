import React from 'react';

export default function Loader({ size = 48 }) {
  return (
    <div className="flex items-center justify-center">
      <div className="w-12 h-12 rounded-full animate-spin border-4 border-white/20 border-t-white" />
    </div>
  );
}
