// frontend/src/components/SmartPackingSuggestions.jsx
import React, { useState } from "react";
import axios from "axios";

export default function SmartPackingSuggestions({ destination, activities }) {
  const [list, setList] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchPacking = async () => {
    try {
      setLoading(true);
      const res = await axios.post(`/api/packing/suggestions`, {
        destination,
        activities,
        startDate: new Date(),
        endDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      });
      setList(res.data);
    } catch (err) {
      console.error("Packing fetch error:", err);
      setList(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 bg-white/10 rounded-2xl shadow-lg">
      <h2 className="text-xl font-semibold mb-3 text-white">🎒 Packing Suggestions</h2>
      <button
        onClick={fetchPacking}
        className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition"
      >
        Get Packing List
      </button>
      {loading && <p className="mt-3 text-gray-300">Loading...</p>}
      {list && (
        <ul className="mt-4 list-disc list-inside text-gray-200">
          {list.recommended.map((item, idx) => (
            <li key={idx}>{item}</li>
          ))}
        </ul>
      )}
    </div>
  );
}
