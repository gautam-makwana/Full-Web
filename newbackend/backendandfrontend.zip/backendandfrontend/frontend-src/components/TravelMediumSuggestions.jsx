// frontend/src/components/TravelMediumSuggestions.jsx
import React, { useState } from "react";
import axios from "axios";

export default function TravelMediumSuggestions({ destination }) {
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchTransport = async () => {
    try {
      setLoading(true);
      const res = await axios.get(`/api/transport/options`, {
        params: { destination },
      });
      setOptions(res.data || []);
    } catch (err) {
      console.error("Transport fetch error:", err);
      setOptions([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 bg-white/10 rounded-2xl shadow-lg">
      <h2 className="text-xl font-semibold mb-3 text-white">
        🚖 Travel Medium Suggestions
      </h2>
      <button
        onClick={fetchTransport}
        className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition"
      >
        Get Transport Options
      </button>
      {loading && <p className="mt-3 text-gray-300">Loading...</p>}
      <ul className="mt-4 space-y-2">
        {options.map((o, idx) => (
          <li
            key={idx}
            className="p-3 rounded-lg bg-black/30 text-gray-200 flex justify-between"
          >
            <span>{o.mode || o.provider}</span>
            <span>{o.price}</span>
            <span>{o.duration}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
