// frontend/src/components/NearbyRecommendations.jsx
import React, { useState } from "react";
import axios from "axios";

export default function NearbyRecommendations({ lat, lng }) {
  const [places, setPlaces] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchNearby = async () => {
    try {
      setLoading(true);
      const res = await axios.get(`/api/nearby/recommendations`, {
        params: { lat, lng },
      });
      setPlaces(res.data || []);
    } catch (err) {
      console.error("Nearby fetch error:", err);
      setPlaces([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 bg-white/10 rounded-2xl shadow-lg">
      <h2 className="text-xl font-semibold mb-3 text-white">📍 Nearby Recommendations</h2>
      <button
        onClick={fetchNearby}
        className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition"
      >
        Find Nearby
      </button>
      {loading && <p className="mt-3 text-gray-300">Loading...</p>}
      <ul className="mt-4 space-y-2 text-gray-200">
        {places.map((p, idx) => (
          <li key={idx} className="p-3 rounded-lg bg-black/30">
            <strong>{p.name}</strong> – {p.address} (⭐ {p.rating || "N/A"})
          </li>
        ))}
      </ul>
    </div>
  );
}
