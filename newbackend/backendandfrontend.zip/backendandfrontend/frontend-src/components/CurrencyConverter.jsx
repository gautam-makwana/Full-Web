// frontend/src/components/CurrencyConverter.jsx
import React, { useState } from "react";
import axios from "axios";

export default function CurrencyConverter() {
  const [from, setFrom] = useState("INR");
  const [to, setTo] = useState("USD");
  const [amount, setAmount] = useState(100);
  const [result, setResult] = useState(null);

  const convert = async () => {
    try {
      const res = await axios.get(`/api/currency/convert`, {
        params: { from, to, amount },
      });
      setResult(res.data);
    } catch (err) {
      console.error("Currency conversion error:", err);
      setResult(null);
    }
  };

  return (
    <div className="p-4 bg-white/10 rounded-2xl shadow-lg text-gray-200">
      <h2 className="text-xl font-semibold mb-3">💱 Currency Converter</h2>
      <div className="flex space-x-2 mb-3">
        <input
          value={from}
          onChange={(e) => setFrom(e.target.value.toUpperCase())}
          className="px-2 py-1 rounded bg-black/30"
          placeholder="From"
        />
        <input
          value={to}
          onChange={(e) => setTo(e.target.value.toUpperCase())}
          className="px-2 py-1 rounded bg-black/30"
          placeholder="To"
        />
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="px-2 py-1 rounded bg-black/30 w-24"
        />
        <button
          onClick={convert}
          className="px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600 transition"
        >
          Convert
        </button>
      </div>
      {result && (
        <p className="text-lg">
          {result.amount} {result.from} ≈{" "}
          <strong>{result.converted?.toFixed(2)}</strong> {result.to}
        </p>
      )}
    </div>
  );
}
