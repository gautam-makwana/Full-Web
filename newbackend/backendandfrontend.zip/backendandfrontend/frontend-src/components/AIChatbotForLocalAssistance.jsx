// frontend/src/components/AIChatbotForLocalAssistance.jsx
import React, { useState } from "react";
import axios from "axios";

export default function AIChatbotForLocalAssistance() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const newMsg = { role: "user", text: input };
    setMessages([...messages, newMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await axios.post(`/api/ai-chatbot/query`, { message: input });
      const reply = { role: "assistant", text: res.data.reply };
      setMessages((prev) => [...prev, reply]);
    } catch (err) {
      console.error("Chatbot error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 bg-white/10 rounded-2xl shadow-lg text-gray-200">
      <h2 className="text-xl font-semibold mb-3">🤖 AI Travel Assistant</h2>
      <div className="h-64 overflow-y-auto bg-black/30 p-3 rounded mb-3">
        {messages.map((m, idx) => (
          <div key={idx} className={`mb-2 ${m.role === "user" ? "text-blue-400" : "text-green-400"}`}>
            <strong>{m.role === "user" ? "You" : "TravelMate"}:</strong> {m.text}
          </div>
        ))}
        {loading && <p className="text-gray-400">Thinking...</p>}
      </div>
      <div className="flex space-x-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="flex-1 px-2 py-1 rounded bg-black/30"
          placeholder="Ask me anything about your trip..."
        />
        <button
          onClick={sendMessage}
          className="px-4 py-2 bg-indigo-500 text-white rounded hover:bg-indigo-600 transition"
        >
          Send
        </button>
      </div>
    </div>
  );
}
