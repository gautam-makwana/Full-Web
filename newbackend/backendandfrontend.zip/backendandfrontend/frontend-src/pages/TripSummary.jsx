/* eslint-disable react-hooks/exhaustive-deps */
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import Navbar from "../components/Navbar";
import { useEffect, useState } from "react";
import { useTripContext } from "../context/TripContext";
import axios from "axios";
import "../index.css";

export default function TripSummary() {
  const { tripData, setTripData } = useTripContext();

  const [trip, setTrip] = useState(null);
  const [loadingTrip, setLoadingTrip] = useState(true);

  // Sync with backend + context
  useEffect(() => {
    const fetchTrip = async () => {
      try {
        const token = localStorage.getItem("tm_token");
        const res = await axios.get("/api/trips/summary", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setTrip(res.data);
        setTripData(res.data);
        localStorage.setItem("tripData", JSON.stringify(res.data));
        localStorage.setItem("tripId", res.data._id);
      } catch (err) {
        console.error("Trip fetch error:", err);
        const localData = JSON.parse(localStorage.getItem("tripData") || "{}");
        if (Object.keys(localData).length) {
          setTrip(localData);
          setTripData(localData);
        }
      } finally {
        setLoadingTrip(false);
      }
    };
    fetchTrip();
  }, []);

  // State for nearby places
  const [nearby, setNearby] = useState([]);
  const [loadingNearby, setLoadingNearby] = useState(true);

  // State for transport
  const [transportResults, setTransportResults] = useState([]);
  const [activeMode, setActiveMode] = useState(null);

  // Packing suggestions
  const [packing, setPacking] = useState([]);

  // Fetch nearby places
  useEffect(() => {
    if (!trip?.destination?.name) return;
    const fetchNearby = async () => {
      setLoadingNearby(true);
      try {
        const { lat, lon } = trip.destination.coords;
        const apiKey = import.meta.env.VITE_GEOAPIFY_KEY;
        const res = await fetch(
          `https://api.geoapify.com/v2/places?categories=tourism.sights,entertainment&filter=circle:${lon},${lat},5000&limit=6&apiKey=${apiKey}`
        );
        const data = await res.json();
        setNearby(
          data.features?.map((f) => ({
            name: f.properties.name || "Unnamed Place",
            category: f.properties.categories?.[0] || "Attraction",
            lat: f.geometry.coordinates[1],
            lon: f.geometry.coordinates[0],
          })) || []
        );
      } catch (err) {
        console.error("Nearby fetch error:", err);
        setNearby([]);
      } finally {
        setLoadingNearby(false);
      }
    };
    fetchNearby();
  }, [trip?.destination]);

  // Transport handler
  const handleTransportClick = async (mode) => {
    setActiveMode(mode);
    try {
      const token = localStorage.getItem("tm_token");
      const res = await axios.get(
        `/api/transport/${mode.toLowerCase()}?from=${trip.origin?.code}&to=${trip.destination?.code}&date=${trip.date}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setTransportResults(res.data.results || []);
    } catch (err) {
      console.error("Transport fetch error:", err);
      setTransportResults([]);
    }
  };

  // Packing suggestions
  useEffect(() => {
    const fetchPacking = async () => {
      try {
        const token = localStorage.getItem("tm_token");
        const res = await axios.get(
          `/api/packing?destination=${trip?.destination?.name}&date=${trip?.date}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setPacking(res.data.suggestions || []);
      } catch (err) {
        console.error("Packing fetch error:", err);
        setPacking([]);
      }
    };
    if (trip?.destination?.name) fetchPacking();
  }, [trip]);

  const tripId = trip?._id || localStorage.getItem("tripId");

  return (
    <div className="min-h-screen text-white animated-gradient-bg font-sans">
      <Navbar />
      <main className="px-6 py-20 max-w-7xl mx-auto text-center space-y-16">
        {/* Title */}
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-5xl md:text-7xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-emerald-400 to-teal-500"
        >
          Your Trip Summary 🧳
        </motion.h1>

        {/* Trip Details */}
        {loadingTrip ? (
          <p className="text-gray-400 italic">Loading trip details...</p>
        ) : trip ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <SummaryCard title="📍 Destination" value={trip.destination?.name} />
            <SummaryCard title="🌍 Mood" value={trip.mood} />
            <SummaryCard
              title="🗓 Date"
              value={trip.date ? new Date(trip.date).toDateString() : "N/A"}
            />
            <SummaryCard title="⏱ Duration" value={trip.duration} />
            <SummaryCard title="💰 Budget" value={`₹${trip.budget}`} />
            <SummaryCard title="👥 Travel Type" value={trip.travelType} />
          </div>
        ) : (
          <p className="text-red-400">No trip data found.</p>
        )}

        {/* Transport */}
        <section>
          <h2 className="text-4xl font-semibold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-fuchsia-500">
            Recommended Transport 🚆✈️
          </h2>
          <div className="flex flex-wrap justify-center gap-4">
            {["flights", "trains", "buses"].map((mode, idx) => (
              <motion.div
                key={idx}
                whileHover={{ scale: 1.1 }}
                className={`px-6 py-3 rounded-full cursor-pointer ${
                  activeMode === mode ? "bg-emerald-500" : "bg-white/10"
                }`}
                onClick={() => handleTransportClick(mode)}
              >
                {mode.toUpperCase()}
              </motion.div>
            ))}
          </div>
          {transportResults.length > 0 && (
            <div className="mt-10 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {transportResults.map((r, idx) => (
                <TransportCard key={idx} data={r} />
              ))}
            </div>
          )}
        </section>

        {/* Nearby */}
        <section>
          <h2 className="text-4xl font-semibold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-violet-600 to-cyan-400">
            Nearby Attractions 🗺️
          </h2>
          {loadingNearby ? (
            <p className="text-gray-400 italic">Fetching nearby attractions...</p>
          ) : nearby.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {nearby.map((place, idx) => (
                <NearbyCard key={idx} place={place} />
              ))}
            </div>
          ) : (
            <p className="text-gray-400">No attractions found.</p>
          )}
        </section>

        {/* Packing */}
        <section>
          <h2 className="text-4xl font-semibold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500">
            Packing Suggestions 🎒
          </h2>
          {packing.length > 0 ? (
            <ul className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {packing.map((item, idx) => (
                <li
                  key={idx}
                  className="bg-white/10 p-4 rounded-xl border border-white/20"
                >
                  {item}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-400">No packing suggestions yet.</p>
          )}
        </section>

        {/* Group Tools */}
        {tripId && (
          <div className="mt-16">
            <Link
              to="/group-tools"
              state={{ tripId }}
              className="inline-block px-8 py-4 rounded-full font-bold text-lg bg-gradient-to-r from-blue-500 to-emerald-500 text-white shadow-xl"
            >
              Open Group Coordination Tools 🛠️
            </Link>
          </div>
        )}
      </main>
    </div>
  );
}

// Small UI cards
function SummaryCard({ title, value }) {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      className="bg-white/5 p-6 rounded-3xl border border-white/10 shadow-xl"
    >
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-200 text-lg">{value || "N/A"}</p>
    </motion.div>
  );
}

function NearbyCard({ place }) {
  return (
    <div className="bg-white/10 p-6 rounded-2xl border border-white/20 shadow-lg text-left">
      <h4 className="text-xl font-bold">{place.name}</h4>
      <p className="text-gray-300 text-sm mt-1">{place.category}</p>
      <a
        href={`https://www.google.com/maps/search/?api=1&query=${place.lat},${place.lon}`}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-block mt-4 px-6 py-2 rounded-full bg-gradient-to-r from-fuchsia-600 to-purple-500 font-semibold"
      >
        View on Map 🗺️
      </a>
    </div>
  );
}

function TransportCard({ data }) {
  return (
    <motion.div
      whileHover={{ scale: 1.05, y: -5 }}
      className="bg-white/10 p-6 rounded-2xl border border-white/20 shadow-lg text-left"
    >
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-lg font-bold text-cyan-300">
          {data.airline || data.name || data.provider}
        </h4>
        {data.flightNumber && (
          <span className="px-3 py-1 text-xs rounded-full bg-cyan-500/20 text-cyan-300">
            {data.flightNumber}
          </span>
        )}
      </div>
      <p className="text-gray-200 text-sm">
        {data.from} → {data.to}
      </p>
      <p className="text-gray-400 text-sm">
        Departure:{" "}
        {data.departure
          ? new Date(data.departure).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })
          : "N/A"}
      </p>
      <p className="text-gray-400 text-sm">
        Arrival:{" "}
        {data.arrival
          ? new Date(data.arrival).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })
          : "N/A"}
      </p>
      <p className="text-gray-300 mt-2">Duration: {data.duration || "N/A"}</p>
      <p className="text-gray-300">
        Price: {data.price ? `₹${data.price}` : "Not available"}
      </p>
      <span
        className={`inline-block mt-3 px-3 py-1 text-xs rounded-full ${
          data.status === "active"
            ? "bg-green-500/20 text-green-400"
            : "bg-yellow-500/20 text-yellow-400"
        }`}
      >
        {data.status || "Scheduled"}
      </span>
    </motion.div>
  );
}
