/* eslint-disable no-unused-vars */
import { useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import { useTripContext } from "../context/TripContext";
import confetti from "canvas-confetti";
import api from "../utils/axios"; // ✅ axios wrapper with baseURL

export default function TripPlanner() {
  const navigate = useNavigate();
  const location = useLocation();
  const { tripData, setTripPlanned, setTripData } = useTripContext();

  // ✅ Load from location.state OR localStorage OR context
  const localData = JSON.parse(localStorage.getItem("tripData") || "{}");

  const initialMood =
    location.state?.mood || tripData?.mood || localData?.mood || "Custom";
  const initialDestination =
    location.state?.destination ||
    tripData?.destination ||
    localData?.destination ||
    { name: "Unknown Destination" };

  const [duration, setDuration] = useState(
    tripData?.duration || localData?.duration || "3 Days"
  );
  const [budget, setBudget] = useState(
    tripData?.budget || localData?.budget || "Medium"
  );
  const [travelType, setTravelType] = useState(
    tripData?.travelType || localData?.travelType || "Couple"
  );
  const [startDate, setStartDate] = useState(
    tripData?.date || localData?.date || ""
  );
  const [endDate, setEndDate] = useState("");

  const mood = initialMood;
  const destination = initialDestination;

  const durations = ["2 Days", "3 Days", "5 Days", "7 Days"];
  const budgets = ["Low", "Medium", "High"];
  const types = ["Solo", "Couple", "Family", "Friends"];

  // 🎯 Auto-calc end date
  useEffect(() => {
    if (startDate && duration) {
      const days = parseInt(duration);
      const sDate = new Date(startDate);
      const eDate = new Date(sDate);
      eDate.setDate(sDate.getDate() + (days - 1));
      setEndDate(eDate.toISOString().split("T")[0]);
    }
  }, [startDate, duration]);

  // ✅ Sync context + localStorage when coming from Results
  useEffect(() => {
    if (location.state?.destination) {
      const updated = {
        ...tripData,
        mood: initialMood,
        destination: initialDestination,
      };
      setTripData(updated);
      localStorage.setItem("tripData", JSON.stringify(updated));
    }
  }, [location.state]);

  const launchConfetti = () => {
    confetti({
      particleCount: 150,
      spread: 90,
      origin: { y: 0.6 },
      colors: ["#8B5CF6", "#EC4899", "#22D3EE"],
    });
  };

  // ✅ Create trip and save in DB + localStorage
    const handleSubmit = async (e) => {
    e.preventDefault();

    const trip = {
      mood,
      destination,
      duration,
      budget,
      travelType,
      date: startDate,
      endDate,
      plannedAt: new Date().toISOString(),
    };

    try {
      // ✅ Must start with "/" so axios.js makes it http://localhost:8080/api/trips
      const { data } = await api.post("/api/trips", trip);  
      setTripData(data.trip);
      setTripPlanned(true);

      // ✅ persist in localStorage
      localStorage.setItem("tripData", JSON.stringify(data.trip));
      localStorage.setItem("tripId", data.trip._id);

      launchConfetti();
      navigate("/trip-summary");
    } catch (err) {
      console.error("Trip creation failed:", err);
    }
  };


  // Framer Motion variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
  };

  const buttonVariants = {
    rest: { scale: 1, boxShadow: "0 0 0px rgba(0,0,0,0)", transition: { duration: 0.2 } },
    hover: { scale: 1.05, boxShadow: "0 0 15px rgba(139, 92, 246, 0.6)", transition: { duration: 0.3 } },
    active: { scale: 0.95, boxShadow: "0 0 5px rgba(139, 92, 246, 0.8)", transition: { duration: 0.1 } },
  };

  return (
    
    <div className="min-h-screen flex flex-col text-white animated-gradient-bg font-sans relative overflow-hidden">
      {/* Background overlays */}
      <div className="absolute inset-0 z-0 opacity-10 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/grid-me.png')]"></div>
      <div className="absolute inset-0 z-0 bg-gradient-to-br from-indigo-900 via-purple-900 to-teal-900 opacity-60"></div>

      <Navbar />
      <section className="flex-grow flex items-center justify-center px-4 py-24 relative z-10">
        <div className="max-w-4xl w-full">
          <motion.h2
            initial={{ opacity: 0, y: -60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-5xl md:text-7xl font-extrabold mb-4 text-center text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-emerald-400 to-teal-500 tracking-wide glow-text"
          >
            Let's Plan Your <span className="italic font-light text-purple-300">{mood}</span> Trip
          </motion.h2>

          {destination?.name && (
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6, ease: "easeOut" }}
              className="mb-16 text-xl md:text-2xl text-center text-gray-300"
            >
              Destination:{" "}
              <span className="font-semibold text-emerald-400 glow-on-hover">
                {destination.name}
              </span>
            </motion.p>
          )}

          <motion.form
            onSubmit={handleSubmit}
            className="grid gap-10 bg-white/5 backdrop-blur-3xl rounded-3xl shadow-2xl p-8 md:p-12 border border-white/10 relative z-20 form-glow-border"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {/* Trip Dates */}
            <motion.div variants={itemVariants}>
              <label className="block mb-6 text-2xl font-bold text-gray-200 section-title-glow">
                📅 Trip Dates
              </label>
              <div className="grid md:grid-cols-2 gap-6">
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="p-4 rounded-xl bg-white/10 border border-white/20 text-gray-200 w-full focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300 input-hover-glow"
                  required
                />
                <input
                  type="text"
                  value={endDate ? endDate : "Auto-calculated"}
                  readOnly
                  className="p-4 rounded-xl bg-white/10 border border-white/20 text-gray-400 w-full focus:outline-none cursor-not-allowed input-hover-glow"
                />
              </div>
            </motion.div>

            {/* Duration */}
            <motion.div variants={itemVariants}>
              <label className="block mb-6 text-2xl font-bold text-gray-200 section-title-glow">
                ⏱ Duration
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {durations.map((d) => (
                  <motion.button
                    type="button"
                    key={d}
                    onClick={() => setDuration(d)}
                    className={`p-5 rounded-xl border-2 transition-all duration-300 glow-on-hover-btn ${
                      duration === d
                        ? "bg-fuchsia-600 text-white border-fuchsia-400 shadow-lg shadow-fuchsia-500/40"
                        : "bg-white/5 text-gray-200 border-white/10 hover:bg-white/20"
                    }`}
                    variants={buttonVariants}
                    whileHover="hover"
                    whileTap="active"
                  >
                    {d}
                  </motion.button>
                ))}
              </div>
            </motion.div>

            {/* Budget */}
            <motion.div variants={itemVariants}>
              <label className="block mb-6 text-2xl font-bold text-gray-200 section-title-glow">
                💰 Budget
              </label>
              <div className="grid grid-cols-3 gap-4">
                {budgets.map((b) => (
                  <motion.button
                    type="button"
                    key={b}
                    onClick={() => setBudget(b)}
                    className={`p-5 rounded-xl border-2 transition-all duration-300 glow-on-hover-btn ${
                      budget === b
                        ? "bg-cyan-600 text-white border-cyan-400 shadow-lg shadow-cyan-500/40"
                        : "bg-white/5 text-gray-200 border-white/10 hover:bg-white/20"
                    }`}
                    variants={buttonVariants}
                    whileHover="hover"
                    whileTap="active"
                  >
                    {b}
                  </motion.button>
                ))}
              </div>
            </motion.div>

            {/* Travel Type */}
            <motion.div variants={itemVariants}>
              <label className="block mb-6 text-2xl font-bold text-gray-200 section-title-glow">
                👥 Travel Type
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {types.map((t) => (
                  <motion.button
                    type="button"
                    key={t}
                    onClick={() => setTravelType(t)}
                    className={`p-5 rounded-xl border-2 transition-all duration-300 glow-on-hover-btn ${
                      travelType === t
                        ? "bg-purple-600 text-white border-purple-400 shadow-lg shadow-purple-500/40"
                        : "bg-white/5 text-gray-200 border-white/10 hover:bg-white/20"
                    }`}
                    variants={buttonVariants}
                    whileHover="hover"
                    whileTap="active"
                  >
                    {t}
                  </motion.button>
                ))}
              </div>
            </motion.div>

            {/* Submit */}
            <motion.button
              type="submit"
              className="w-full mt-6 px-6 py-4 rounded-full font-bold text-xl bg-gradient-to-r from-blue-500 to-emerald-500 text-white relative overflow-hidden submit-btn-glow cursor-pointer"
              whileHover={{ scale: 1.02, boxShadow: "0 0 25px rgba(60, 200, 200, 0.7)" }}
              whileTap={{ scale: 0.98 }}
              transition={{ duration: 0.2 }}
            >
              <span className="relative z-10">Generate Trip Plan 🚀</span>
              <span className="absolute inset-0 bg-gradient-to-r from-blue-400 via-emerald-400 to-teal-500 opacity-0 hover:opacity-10 transition-opacity duration-300 rounded-full"></span>
            </motion.button>
          </motion.form>
        </div>
      </section>
    </div>
  );
}
