// frontend/src/pages/SmartPackingSuggestions.jsx
import React from "react";
import SmartPackingSuggestions from "../components/SmartPackingSuggestions";
import Navbar from "../components/Navbar";

export default function SmartPackingSuggestionsPage() {
  return (
    <div className="animated-gradient-bg min-h-screen text-gray-200">
      <Navbar />
      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-3xl font-bold mb-6">🎒 Smart Packing Suggestions</h1>
        <SmartPackingSuggestions destination="Delhi" activities={["trekking", "cultural"]} />
      </div>
    </div>
  );
}
