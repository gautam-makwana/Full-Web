// frontend/src/pages/AIChatbotForLocalAssistance.jsx
import React from "react";
import AIChatbotForLocalAssistance from "../components/AIChatbotForLocalAssistance";
import Navbar from "../components/Navbar";

export default function AIChatbotForLocalAssistancePage() {
  return (
    <div className="animated-gradient-bg min-h-screen text-gray-200">
      <Navbar />
      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-3xl font-bold mb-6">🤖 AI Travel Assistant</h1>
        <AIChatbotForLocalAssistance />
      </div>
    </div>
  );
}
