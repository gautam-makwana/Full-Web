// frontend/src/pages/CurrencyConverter.jsx
import React from "react";
import CurrencyConverter from "../components/CurrencyConverter";
import Navbar from "../components/Navbar";

export default function CurrencyConverterPage() {
  return (
    <div className="animated-gradient-bg min-h-screen text-gray-200">
      <Navbar />
      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-3xl font-bold mb-6">💱 Currency Converter</h1>
        <CurrencyConverter />
      </div>
    </div>
  );
}
