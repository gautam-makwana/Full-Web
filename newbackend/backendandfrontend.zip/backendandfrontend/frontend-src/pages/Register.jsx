/* eslint-disable no-unused-vars */
import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  User,
  Mail,
  Lock,
  Eye,
  EyeOff,
  Loader2,
  CheckCircle,
  XCircle,
} from "lucide-react";
import axios from "axios";

const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8080";

const cn = (...classes) => classes.filter(Boolean).join(" ");

const cardVariants = {
  hidden: { opacity: 0, y: 50, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 10,
      delay: 0.2,
      when: "beforeChildren",
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const Toast = ({ message, type, onClose }) => {
  useEffect(() => {
    if (message) {
      const timer = setTimeout(onClose, 3000);
      return () => clearTimeout(timer);
    }
  }, [message, onClose]);

  const colors = {
    success: "bg-green-600",
    error: "bg-red-600",
  };

  const icons = {
    success: <CheckCircle className="h-5 w-5 text-white" />,
    error: <XCircle className="h-5 w-5 text-white" />,
  };

  return (
    <AnimatePresence>
      {message && (
        <motion.div
          initial={{ y: -50, opacity: 0, scale: 0.8 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          exit={{ y: -50, opacity: 0, scale: 0.8 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
          className={cn(
            "fixed top-4 left-1/2 -translate-x-1/2 p-4 rounded-full shadow-lg z-50 flex items-center gap-3 font-semibold text-sm text-white",
            colors[type]
          )}
        >
          {icons[type]}
          <span>{message}</span>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default function Register() {
  const navigate = useNavigate();

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [travelType, setTravelType] = useState("solo");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [toast, setToast] = useState({ message: "", type: "" });

  const validateForm = () => {
    const newErrors = {};
    if (!fullName.trim()) newErrors.fullName = "Full name is required.";
    if (!email) {
      newErrors.email = "Email is required.";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Email address is invalid.";
    }
    if (!password) {
      newErrors.password = "Password is required.";
    } else if (password.length < 6) {
      newErrors.password = "Password must be at least 6 characters.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      setToast({ message: "Please fix the errors in the form.", type: "error" });
      return;
    }

    setLoading(true);

    try {
      const res = await axios.post(`${API_BASE}/api/auth/register`, {
        name: fullName,
        email,
        password,
        travelType,
      });

      // Save token
      localStorage.setItem("tm_token", res.data.token);

      setToast({ message: "Registration successful!", type: "success" });

      setFullName("");
      setEmail("");
      setPassword("");

      // ✅ Redirect to TravelType
      setTimeout(() => navigate("/travel-type"), 1500);
    } catch (err) {
      const msg =
        err.response?.data?.error || err.message || "Registration failed.";
      setToast({ message: msg, type: "error" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <style>{`
        .animated-gradient-bg {
          background: linear-gradient(-45deg, #0a0a0a, #1a1a1a, #0a0a0a, #1a1a1a);
          background-size: 400% 400%;
          animation: gradient-animation 15s ease infinite;
        }
        @keyframes gradient-animation {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>

      <div className="min-h-screen animated-gradient-bg text-white font-sans flex flex-col relative overflow-hidden">
        <section className="flex-grow flex items-center justify-center px-4 md:px-6 py-12 relative z-10">
          <motion.div
            className="w-full max-w-md p-8 rounded-3xl bg-white/5 backdrop-blur-3xl shadow-2xl border border-white/10 relative z-10"
            variants={cardVariants}
            initial="hidden"
            animate="visible"
            whileHover={{ scale: 1.01, transition: { duration: 0.3 } }}
          >
            <div className="flex flex-col items-center mb-8">
              <motion.h2
                className="text-4xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-emerald-400 to-teal-500 mb-2"
                variants={itemVariants}
              >
                Join Us
              </motion.h2>
              <motion.p
                className="text-gray-300 text-center"
                variants={itemVariants}
              >
                Create your account to get started.
              </motion.p>
            </div>

            <motion.form
              onSubmit={handleSubmit}
              className="space-y-6"
              variants={itemVariants}
            >
              {/* Full Name */}
              <div className="relative">
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  onBlur={validateForm}
                  placeholder="Full Name"
                  className={cn(
                    "w-full px-12 py-3 rounded-xl bg-white/10 text-white placeholder-gray-400 focus:outline-none focus:ring-2 transition-all duration-300",
                    errors.fullName
                      ? "ring-red-500 border border-red-500"
                      : "ring-transparent focus:ring-blue-400 border border-transparent focus:border-blue-400"
                  )}
                />
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                {errors.fullName && (
                  <p className="mt-2 text-xs text-red-400">{errors.fullName}</p>
                )}
              </div>

              {/* Email */}
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onBlur={validateForm}
                  placeholder="Email Address"
                  className={cn(
                    "w-full px-12 py-3 rounded-xl bg-white/10 text-white placeholder-gray-400 focus:outline-none focus:ring-2 transition-all duration-300",
                    errors.email
                      ? "ring-red-500 border border-red-500"
                      : "ring-transparent focus:ring-emerald-400 border border-transparent focus:border-emerald-400"
                  )}
                />
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                {errors.email && (
                  <p className="mt-2 text-xs text-red-400">{errors.email}</p>
                )}
              </div>

              {/* Password */}
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onBlur={validateForm}
                  placeholder="Password"
                  className={cn(
                    "w-full px-12 py-3 rounded-xl bg-white/10 text-white placeholder-gray-400 focus:outline-none focus:ring-2 transition-all duration-300",
                    errors.password
                      ? "ring-red-500 border border-red-500"
                      : "ring-transparent focus:ring-teal-400 border border-transparent focus:border-teal-400"
                  )}
                />
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
                {errors.password && (
                  <p className="mt-2 text-xs text-red-400">{errors.password}</p>
                )}
              </div>

              {/* Travel Type */}
              <div>
                <label className="block mb-2 text-gray-300 text-sm">
                  Travel Type
                </label>
                <select
                  value={travelType}
                  onChange={(e) => setTravelType(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-white/10 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-blue-400"
                >
                  <option value="solo">Solo</option>
                  <option value="group">Group</option>
                </select>
              </div>

              {/* Submit */}
              <motion.button
                whileHover={{
                  scale: 1.02,
                  boxShadow: "0 0 30px rgba(0, 255, 127, 0.8)",
                  y: -2,
                }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                disabled={loading}
                className={cn(
                  "w-full flex items-center justify-center gap-2 font-bold text-lg py-3 rounded-xl shadow-lg transition-all duration-300 transform-gpu",
                  loading
                    ? "bg-gray-500/50 text-gray-300 cursor-not-allowed"
                    : "bg-gradient-to-r from-blue-500 to-emerald-500 text-white hover:shadow-[0_0_25px_rgba(129,140,248,0.5)]"
                )}
              >
                {loading ? (
                  <>
                    <Loader2 className="animate-spin" size={24} />
                    Registering...
                  </>
                ) : (
                  "Register"
                )}
              </motion.button>
            </motion.form>

            {/* Login Link */}
            <motion.div
              variants={itemVariants}
              className="mt-8 text-center text-sm space-y-2"
            >
              <p className="text-gray-400">
                Already have an account?{" "}
                <button
                  onClick={() => navigate("/login")}
                  className="text-blue-400 hover:underline font-semibold cursor-pointer"
                >
                  Login
                </button>
              </p>
            </motion.div>
          </motion.div>
        </section>

        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast({ message: "", type: "" })}
        />
      </div>
    </>
  );
}
