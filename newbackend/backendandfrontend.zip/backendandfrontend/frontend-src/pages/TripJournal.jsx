import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import axios from "axios";

// ---------------- Background with Gray Bubbles + Sparkles ----------------
// 🌌 Background with Moving Gradient + Random Floating Bubbles + Sparkles
const Background = () => (
  <div className="absolute inset-0 overflow-hidden -z-10">
    {/* Animated Gradient Layer */}
    <motion.div
      className="absolute inset-0"
      style={{
        background: "linear-gradient(270deg, #0a0a0a, #1f1f1f, #2a2a2a, #0f0f0f)",
        backgroundSize: "600% 600%",
      }}
      animate={{ backgroundPosition: ["0% 0%", "100% 100%", "0% 0%"] }}
      transition={{
        duration: 50,
        ease: "linear",
        repeat: Infinity,
      }}
    />

    {/* Floating Random Bubbles */}
    {[...Array(15)].map((_, i) => {
      const size = Math.random() * 40 + 25;
      const startX = Math.random() * 100; // random start position
      return (
        <motion.div
          key={`bubble-${i}`}
          className="absolute rounded-full pointer-events-none"
          style={{
            width: size,
            height: size,
            background: "radial-gradient(circle, rgba(220,220,220,0.18) 0%, transparent 70%)",
            left: `${startX}%`,
            bottom: `-${size}px`,
          }}
          animate={{
            y: [0, -(window.innerHeight + size)], // float up
            x: [
              0,
              Math.random() * 40 - 20, // drift left/right
              Math.random() * 60 - 30,
              Math.random() * 40 - 20,
              0,
            ],
            scale: [1, 1.1, 0.9, 1], // gentle pulse
            opacity: [0, 0.25, 0],
          }}
          transition={{
            duration: Math.random() * 25 + 20,
            repeat: Infinity,
            ease: "easeInOut",
            delay: Math.random() * 12,
          }}
        />
      );
    })}

    {/* Sparkles */}
    {[...Array(30)].map((_, i) => (
      <motion.div
        key={`sparkle-${i}`}
        className="absolute rounded-full pointer-events-none"
        style={{
          width: 3,
          height: 3,
          background: ["#ffffff", "#a3e635", "#38bdf8"][i % 3],
          left: `${Math.random() * 100}%`,
          top: `${Math.random() * 100}%`,
        }}
        animate={{ opacity: [0, 1, 0], scale: [0.6, 1.3, 0.6] }}
        transition={{
          duration: Math.random() * 4 + 2,
          repeat: Infinity,
          delay: Math.random() * 5,
        }}
      />
    ))}
  </div>
);


// ---------------- Journal Card ----------------
const JournalCard = ({ entry, handleDelete }) => (
  <motion.div
    layout
    initial={{ opacity: 0, y: 50, scale: 0.9 }}
    animate={{ opacity: 1, y: 0, scale: 1 }}
    exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
    transition={{ type: "spring", stiffness: 100, damping: 20 }}
    className="relative bg-white/5 backdrop-blur-2xl rounded-3xl border border-white/10 p-6 shadow-xl overflow-hidden group hover:shadow-[0_0_40px_-5px_rgba(56,189,248,0.6)] hover:border-cyan-400 transition-all duration-300"
  >
    <div className="flex flex-col md:flex-row md:items-start justify-between mb-4">
      <div>
        <h3 className="text-2xl font-bold text-cyan-300 group-hover:text-cyan-200 transition-colors duration-300">
          {entry.title}
        </h3>
        <span className="text-sm text-gray-400">
          {new Date(entry.createdAt).toLocaleDateString()}
        </span>
      </div>
      <motion.button
        onClick={() => handleDelete(entry._id)}
        whileHover={{ scale: 1.1, rotate: 15 }}
        whileTap={{ scale: 0.9 }}
        className="mt-2 md:mt-0 p-3 text-white bg-red-600/60 rounded-full hover:bg-red-700/80 transition-colors duration-200"
      >
        ✕
      </motion.button>
    </div>
    <p className="text-gray-200 mb-4">{entry.content}</p>
    {entry.photos?.length > 0 && (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {entry.photos.map((p) => (
          <motion.img
            key={p.url}
            src={p.url}
            alt="Trip"
            className="rounded-xl w-full max-h-64 object-cover shadow-xl border border-white/10"
            initial={{ scale: 0.95, opacity: 0, filter: "grayscale(100%)" }}
            animate={{ scale: 1, opacity: 1, filter: "grayscale(0%)" }}
            transition={{ duration: 0.6 }}
          />
        ))}
      </div>
    )}
  </motion.div>
);

// ---------------- Main Page ----------------
export default function TripJournal() {
  const navigate = useNavigate();
  const [entries, setEntries] = useState([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [photos, setPhotos] = useState([]);
  const [isFormLoading, setIsFormLoading] = useState(false);
  const [loading, setLoading] = useState(true);

  const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8080/api";
  const token = localStorage.getItem("tm_token");

  useEffect(() => {
    if (!token) {
      navigate("/login");
      return;
    }

    const fetchEntries = async () => {
      try {
        const res = await axios.get(`${API_BASE}/api/journal`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setEntries(res.data.entries || []);
      } catch (err) {
        console.error("Error fetching journal entries:", err);
        if (err.response?.status === 401) navigate("/login");
      } finally {
        setLoading(false);
      }
    };
    fetchEntries();
  }, [token, API_BASE, navigate]);

  const handleAddEntry = async (e) => {
    e.preventDefault();
    if (!title || !content || isFormLoading) return;

    setIsFormLoading(true);
    try {
      const formData = new FormData();
      formData.append("title", title);
      formData.append("content", content);
      photos.forEach((file) => formData.append("photos", file));

      const res = await axios.post(`${API_BASE}/api/journal`, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });

      setEntries([res.data.entry, ...entries]);
      setTitle("");
      setContent("");
      setPhotos([]);
    } catch (err) {
      console.error("Error adding journal entry:", err);
      if (err.response?.status === 401) navigate("/login");
    } finally {
      setIsFormLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_BASE}/api/journal/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setEntries(entries.filter((entry) => entry._id !== id));
    } catch (err) {
      console.error("Error deleting entry:", err);
      if (err.response?.status === 401) navigate("/login");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen text-white flex items-center justify-center bg-gray-900">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-cyan-400 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen text-white font-sans relative overflow-hidden">
      <Background />
      <div className="max-w-7xl mx-auto py-24 px-6 relative z-10 grid gap-16 lg:grid-cols-2">
        {/* FORM */}
        <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }}>
          <h2 className="text-4xl lg:text-5xl font-extrabold text-center mb-8 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
            Create a New Entry ✍️
          </h2>
          <form
            onSubmit={handleAddEntry}
            className="grid gap-6 bg-white/5 backdrop-blur-2xl p-8 rounded-3xl border border-white/10 shadow-2xl"
          >
            <input
              type="text"
              placeholder="Entry Title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="w-full bg-black/30 text-white px-4 py-3 rounded-xl border border-white/10"
            />
            <textarea
              rows="4"
              placeholder="Your experience..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              required
              className="w-full bg-black/30 text-white px-4 py-3 rounded-xl border border-white/10"
            />
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={(e) => setPhotos([...e.target.files])}
              className="block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-cyan-600/70 file:text-white hover:file:bg-cyan-700/80"
            />
            {photos.length > 0 && (
              <div className="grid grid-cols-2 gap-4">
                {Array.from(photos).map((file, idx) => (
                  <img
                    key={idx}
                    src={URL.createObjectURL(file)}
                    alt="Preview"
                    className="rounded-xl w-full max-h-48 object-cover border-2 border-white/30 shadow-lg"
                  />
                ))}
              </div>
            )}
            <button
              type="submit"
              disabled={isFormLoading}
              className="mt-4 w-full py-4 rounded-full font-bold text-lg shadow-xl text-white bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500"
            >
              {isFormLoading ? "Adding Entry..." : "Add Entry ✍️"}
            </button>
          </form>
        </motion.div>

        {/* LIST */}
        <div className="lg:max-h-[85vh] overflow-y-auto pr-4">
          <h2 className="text-4xl lg:text-5xl font-extrabold text-center mb-8 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
            My Journal 📔
          </h2>
          <AnimatePresence>
            {entries.length > 0 ? (
              <div className="grid gap-8">
                {entries.map((entry) => (
                  <JournalCard key={entry._id} entry={entry} handleDelete={handleDelete} />
                ))}
              </div>
            ) : (
              <p className="text-gray-400 text-center text-lg italic mt-10">
                Your journal is empty. Add your first memory!
              </p>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
