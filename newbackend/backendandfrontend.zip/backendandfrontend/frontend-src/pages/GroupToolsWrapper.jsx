import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useTripContext } from "../context/TripContext";
import GroupTools from "./GroupTools";

export default function GroupToolsWrapper() {
  const location = useLocation();
  const navigate = useNavigate();
  const { tripData, user } = useTripContext();

  const stateTripId = location.state?.tripId;
  const ctxTripId = tripData?._id;
  const stored = localStorage.getItem("tripId");

  const tripId = stateTripId || ctxTripId || stored || null;

  if (!tripId) {
    return (
      <div className="min-h-screen flex items-center justify-center text-white bg-gray-900 p-6">
        <div className="max-w-md text-center">
          <h2 className="text-2xl font-bold mb-4">No trip selected!</h2>
          <p className="mb-6">Please plan a trip first.</p>
          <div className="flex justify-center gap-4">
            <button onClick={() => navigate("/trip-planner")} className="px-4 py-2 rounded bg-blue-600">
              Plan a Trip
            </button>
            <button onClick={() => navigate("/")} className="px-4 py-2 rounded bg-gray-700">
              Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  localStorage.setItem("tripId", tripId);

  return <GroupTools tripId={tripId} user={user} />;
}
