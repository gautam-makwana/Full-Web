// frontend/src/pages/NearbyRecommendations.jsx
import React from "react";
import NearbyRecommendations from "../components/NearbyRecommendations";
import Navbar from "../components/Navbar";

export default function NearbyRecommendationsPage() {
  return (
    <div className="animated-gradient-bg min-h-screen text-gray-200">
      <Navbar />
      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-3xl font-bold mb-6">📍 Nearby Recommendations</h1>
        <NearbyRecommendations lat={28.6139} lng={77.209} />
      </div>
    </div>
  );
}
