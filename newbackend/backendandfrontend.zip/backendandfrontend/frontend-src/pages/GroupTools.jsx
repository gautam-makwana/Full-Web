import React, { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Users, CheckCircle, MessageCircle, DollarSign, Calendar, Sun, Moon, Plus, Edit2, Trash2, X, Check, Loader, Sparkles } from "lucide-react";
import axios from "axios";
import { io } from "socket.io-client";

// API constants
const RAW_API = "http://localhost:8080";
const API_HOST = String(RAW_API).replace(/\/api\/?$/i, "").replace(/\/$/, "");
const API_BASE = `${API_HOST}/api`;

// Gemini API Key - Please paste your key here
const geminiApiKey = "YOUR_API_KEY_HERE";
const geminiApiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-05-20:generateContent?key=${geminiApiKey}`;

// ----------------- UI COMPONENTS -----------------
const SectionCard = ({ children, className = "" }) => (
  <motion.div
    className={`p-6 md:p-8 rounded-3xl border border-cyan-800/30 bg-gray-900/40 backdrop-blur-md shadow-2xl shadow-cyan-900/30 transition-all duration-300 hover:shadow-cyan-900/60 ${className}`}
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6 }}
  >
    {children}
  </motion.div>
);

const Input = ({ className = "", ...props }) => (
  <input
    className={`px-4 py-3 rounded-2xl border-2 border-gray-700/60 bg-gray-800/50 text-white placeholder:text-gray-500 shadow-inner shadow-black/30 transition-all duration-300 focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 focus:shadow-cyan-400/20 w-full ${className}`}
    {...props}
  />
);

const IconButton = ({ icon: Icon, onClick, className = "", children }) => (
  <motion.button
    whileHover={{ scale: 1.1, rotate: 5, boxShadow: "0 0 10px rgba(0, 255, 240, 0.4)" }}
    whileTap={{ scale: 0.95 }}
    onClick={onClick}
    className={`p-2 rounded-full text-cyan-400 transition-colors duration-200 hover:bg-cyan-400/20 hover:text-white ${className}`}
  >
    {Icon && <Icon className="w-5 h-5" />}
    {children}
  </motion.button>
);

const PrimaryButton = ({ onClick, children, className = "", disabled = false }) => (
  <motion.button
    whileHover={{ scale: 1.05, boxShadow: "0 0 20px rgba(0,255,240,0.6)" }}
    whileTap={{ scale: 0.98 }}
    onClick={!disabled ? onClick : undefined}
    disabled={disabled}
    className={`w-full md:w-auto px-5 py-3 rounded-2xl font-bold text-gray-950 transition-all duration-300 transform bg-gradient-to-r from-cyan-400 to-teal-300 hover:from-cyan-300 hover:to-teal-200 ${disabled ? "opacity-40 cursor-not-allowed" : "cursor-pointer"} ${className}`}
  >
    {children}
  </motion.button>
);

const OutlineButton = ({ onClick, children, className = "", disabled = false }) => (
  <motion.button
    whileHover={{ scale: 1.05, boxShadow: "0 0 10px rgba(0,255,240,0.4)" }}
    whileTap={{ scale: 0.98 }}
    onClick={!disabled ? onClick : undefined}
    disabled={disabled}
    className={`w-full md:w-auto px-5 py-3 rounded-2xl font-semibold border-2 border-cyan-400 text-cyan-400 transition-all duration-300 transform backdrop-blur-sm hover:bg-cyan-400 hover:text-gray-950 ${disabled ? "opacity-40 cursor-not-allowed" : "cursor-pointer"} ${className}`}
  >
    {children}
  </motion.button>
);

const Toast = ({ message, type, onClose }) => {
  const bgColor = type === "success" ? "bg-green-500" : "bg-red-500";
  return (
    <motion.div
      initial={{ opacity: 0, y: -30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -30 }}
      className={`fixed top-24 left-1/2 -translate-x-1/2 z-50 text-white font-semibold px-6 py-3 rounded-full shadow-2xl flex items-center gap-4 border-2 border-white/20 ${bgColor}`}
    >
      <div>{message}</div>
      <IconButton icon={X} onClick={onClose} className="ml-2 text-white hover:bg-white/10 hover:text-white" />
    </motion.div>
  );
};

const Modal = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-lg p-8 rounded-3xl bg-gray-900 border-2 border-cyan-800/50 shadow-2xl shadow-cyan-900/60"
      >
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-white text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-400">{title}</h3>
          <IconButton icon={X} onClick={onClose} />
        </div>
        {children}
      </motion.div>
    </div>
  );
};

// ----------------- HELPERS -----------------
const toArray = (payload) => {
  if (!payload) return [];
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload.data)) return payload.data;
  return [];
};

const uniqueMembers = (arr) => {
  if (!Array.isArray(arr)) return [];
  const seen = new Set();
  return arr.filter((m) => {
    if (!m) return false;
    const key = m._id || m.name?.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
};

const getInitials = (name) => {
  if (!name) return "?";
  const parts = name.split(" ").filter(p => p.length > 0);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
  return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
};

// ----------------- MAIN COMPONENT -----------------
export default function App({ tripId, user }) {
  const [activeTab, setActiveTab] = useState("members");
  const [toast, setToast] = useState(null);
  const toastTimeoutRef = useRef(null);
  const [darkMode, setDarkMode] = useState(true);
  const [isAppReady, setIsAppReady] = useState(false);
  const tabRefs = useRef([]);
  const [tabIndicator, setTabIndicator] = useState({ left: 0, width: 0 });
  const [isGenerating, setIsGenerating] = useState(false);

  const [members, setMembers] = useState([]);
  const [newMember, setNewMember] = useState("");
  const [editingMember, setEditingMember] = useState(null);

  const [expenses, setExpenses] = useState([]);
  const [newExpense, setNewExpense] = useState({ description: "", amount: "" });
  const [editingExpense, setEditingExpense] = useState(null);

  const [checklist, setChecklist] = useState([]);
  const [newTask, setNewTask] = useState("");
  const [editingTask, setEditingTask] = useState(null);

  const [polls, setPolls] = useState([]);
  const [newPoll, setNewPoll] = useState({ question: "", options: [{ text: "" }, { text: "" }] });
  const [editingPoll, setEditingPoll] = useState(null);

  const [announcements, setAnnouncements] = useState([]);
  const [newAnnouncement, setNewAnnouncement] = useState("");
  const [editingAnnouncement, setEditingAnnouncement] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const userId = user?.id || user?._id || null;
  const socketRef = useRef(null);

  // Fetch all trip group data
  const fetchAll = async (tId) => {
    if (!tId) return;
    setIsLoading(true);
    try {
      const [m, e, c, p, a] = await Promise.all([
        axios.get(`${API_BASE}/group-tools/${tId}/members`),
        axios.get(`${API_BASE}/group-tools/${tId}/expenses`),
        axios.get(`${API_BASE}/group-tools/${tId}/checklist`),
        axios.get(`${API_BASE}/group-tools/${tId}/polls`),
        axios.get(`${API_BASE}/group-tools/${tId}/announcements`),
      ]);
      setMembers(uniqueMembers(toArray(m.data)));
      setExpenses(toArray(e.data));
      setChecklist(toArray(c.data));
      setPolls(toArray(p.data));
      setAnnouncements(toArray(a.data));
    } catch (err) {
      console.error("Fetch error:", err);
      showToast("Failed to load group data", "error");
    } finally {
      setIsLoading(false);
    }
  };

  const showToast = (message, type = "success") => {
    if (toastTimeoutRef.current) {
      clearTimeout(toastTimeoutRef.current);
    }
    setToast({ message, type });
    toastTimeoutRef.current = setTimeout(() => setToast(null), 3000);
  };

  // ----------------- SOCKET.IO -----------------
  useEffect(() => {
    if (!tripId) return;

    const token = localStorage.getItem("token") || "";
    if (!token) return showToast("No auth token found", "error");

    // Safeguard against double-connecting the socket
    if (socketRef.current) return;

    const socket = io(API_HOST, {
      path: "/socket.io",
      transports: ["websocket"],
      auth: { token },
      autoConnect: false,
      withCredentials: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    });

    socketRef.current = socket;

    socket.on("connect", () => {
      console.log("✅ Socket connected:", socket.id);
      socket.emit("joinRoom", tripId);
    });

    socket.on("connect_error", (err) => {
      console.error("Socket connect_error:", err.message);
      showToast("Socket connection failed: " + err.message, "error");
    });

    ["updateMembers", "updateExpenses", "updateChecklist", "updatePolls", "updateAnnouncements"].forEach(
      (ev) => socket.on(ev, () => fetchAll(tripId))
    );

    socket.connect();

    return () => {
      socket.emit("leaveRoom", tripId);
      socket.disconnect();
      socketRef.current = null;
    };
  }, [tripId]);

  useEffect(() => {
    if (tripId) fetchAll(tripId);
  }, [tripId]);

  // Check if app is ready based on number of members
  useEffect(() => {
    const isReady = members.length >= 2;
    setIsAppReady(isReady);
    if (!isReady && activeTab !== "members" && activeTab !== "announcements") {
      setActiveTab("members");
      showToast("Please add at least 2 members to enable other features.", "error");
    }
  }, [members, activeTab]);
  
  // Update tab indicator position
  useEffect(() => {
    const activeTabIndex = Object.keys(tabData).indexOf(activeTab);
    const activeTabRef = tabRefs.current[activeTabIndex];
    if (activeTabRef) {
      setTabIndicator({
        left: activeTabRef.offsetLeft,
        width: activeTabRef.offsetWidth,
      });
    }
  }, [activeTab, members]);

  const crud = async (endpoint, data, method = "post") => {
    try {
      const url = `${API_BASE}/group-tools/${tripId}/${endpoint}`;
      let response;
      if (method === "post") {
        response = await axios.post(url, data);
      } else if (method === "patch") {
        response = await axios.patch(url, data);
      } else if (method === "delete") {
        response = await axios.delete(url, { data });
      }

      if (response && (response.status === 200 || response.status === 201)) {
        showToast("Action successful!", "success");
        fetchAll(tripId);
      } else {
        throw new Error("Action failed");
      }
    } catch (err) {
      console.error("CRUD error:", err);
      showToast("Error performing action", "error");
    }
  };
  
  const handleVote = async (pollId, optionIndex) => {
    try {
      const response = await axios.patch(`${API_BASE}/group-tools/${tripId}/polls/${pollId}/vote`, {
        userId,
        optionIndex,
      });
      if (response.status === 200) {
        showToast("Vote cast successfully!", "success");
        fetchAll(tripId);
      } else {
        throw new Error("Voting failed");
      }
    } catch (err) {
      console.error("Voting error:", err);
      showToast("You have already voted on this poll.", "error");
    }
  };
  
  const handleCompleteTask = async (taskId, isCompleted) => {
    try {
      const response = await axios.patch(`${API_BASE}/group-tools/${tripId}/checklist/${taskId}`, { completed: isCompleted });
      if (response.status === 200) {
        showToast("Task updated successfully!", "success");
        fetchAll(tripId);
      } else {
        throw new Error("Task update failed");
      }
    } catch (err) {
      console.error("Task completion error:", err);
      showToast("Error updating task status.", "error");
    }
  };
  
  const handleGenerateChecklist = async () => {
    setIsGenerating(true);
    const prompt = `Generate a list of 5-7 short and practical travel checklist items for a group trip. The items should be simple and generic. Format the response as a JSON array of strings. Do not include any other text or formatting.`;
    const payload = {
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "ARRAY",
          items: {
            type: "STRING"
          }
        }
      }
    };

    try {
      const response = await fetch(geminiApiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.json();
      const generatedItems = result.candidates?.[0]?.content?.parts?.[0]?.text;
      const parsedItems = JSON.parse(generatedItems);

      if (Array.isArray(parsedItems)) {
        for (const item of parsedItems) {
          if (item && item.trim()) {
            await crud("checklist", { item: item.trim(), completed: false }, "post");
          }
        }
        showToast("Checklist items generated successfully!", "success");
      } else {
        throw new Error("Invalid response format from Gemini API.");
      }
    } catch (error) {
      console.error("Gemini API Error:", error);
      showToast("Failed to generate checklist items.", "error");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDraftAnnouncement = async () => {
    setIsGenerating(true);
    const prompt = `Write a friendly and brief announcement for a group trip. The announcement should be based on the following notes: "${newAnnouncement}". The tone should be encouraging. Do not include a subject line.`;
    const payload = {
      contents: [{ parts: [{ text: prompt }] }],
    };

    try {
      const response = await fetch(geminiApiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.json();
      const draftedText = result.candidates?.[0]?.content?.parts?.[0]?.text;

      if (draftedText) {
        setNewAnnouncement(draftedText.trim());
        showToast("Announcement drafted successfully!", "success");
      } else {
        throw new Error("Invalid response from Gemini API.");
      }
    } catch (error) {
      console.error("Gemini API Error:", error);
      showToast("Failed to draft announcement.", "error");
    } finally {
      setIsGenerating(false);
    }
  };

  // ----------------- TABS -----------------
  const tabData = {
    members: { icon: Users, label: "Members", render: () => renderMembers() },
    expenses: { icon: DollarSign, label: "Expenses", render: () => renderExpenses(), disabled: !isAppReady },
    checklist: { icon: CheckCircle, label: "Checklist", render: () => renderChecklist(), disabled: !isAppReady },
    polls: { icon: MessageCircle, label: "Polls", render: () => renderPolls(), disabled: !isAppReady },
    announcements: { icon: Calendar, label: "Announcements", render: () => renderAnnouncements() },
  };

  // ----------------- RENDER -----------------
  return (
    <div className={`${darkMode ? "dark" : "light"} relative min-h-screen flex flex-col items-center font-sans bg-gray-950 text-white transition-colors antialiased`}>
      {/* Background with subtle neon gradient animation */}
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-gray-950 via-gray-900 to-black animate-pulse-slow opacity-60"></div>
      
      <AnimatePresence>
        {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      </AnimatePresence>

      <main className="container mx-auto px-4 py-12 md:py-20 max-w-6xl w-full">
        <header className="flex flex-col md:flex-row justify-between items-center mb-8 p-4 md:p-6 bg-gray-900/40 backdrop-blur-md rounded-3xl border border-cyan-800/30 shadow-2xl shadow-cyan-900/30">
          <h1 className="text-4xl md:text-5xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-fuchsia-400">
            Trip Group Tools
          </h1>
          <IconButton onClick={() => setDarkMode(!darkMode)} className="mt-4 md:mt-0">
            {darkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
          </IconButton>
        </header>

        <nav className="mb-8 flex justify-center p-2 rounded-full bg-gray-900/50 border-2 border-gray-700/60 backdrop-blur-md shadow-inner shadow-black/30">
          <div className="relative inline-flex space-x-2 overflow-x-auto hide-scrollbar">
            <motion.div
              className="absolute h-full rounded-full bg-gradient-to-r from-cyan-600 to-fuchsia-600 shadow-lg shadow-fuchsia-500/40"
              initial={false}
              animate={{ left: tabIndicator.left, width: tabIndicator.width }}
              transition={{ type: "spring", stiffness: 500, damping: 30 }}
            />
            {Object.keys(tabData).map((tab, index) => {
              const IconComponent = tabData[tab].icon;
              return (
                <motion.button
                  key={tab}
                  ref={(el) => (tabRefs.current[index] = el)}
                  onClick={() => setActiveTab(tab)}
                  disabled={tabData[tab].disabled}
                  className={`relative flex-shrink-0 flex items-center gap-2 px-5 py-2 rounded-full transition-all duration-300 font-bold z-10 ${tabData[tab].disabled ? "opacity-50 cursor-not-allowed text-gray-500" : activeTab === tab ? "text-white" : "text-gray-400 hover:text-white"}`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <IconComponent className="w-5 h-5" />
                  <span>{tabData[tab].label}</span>
                </motion.button>
              );
            })}
          </div>
        </nav>

        <style>
          {`
          @keyframes pulse-slow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
          }
          .animate-pulse-slow {
            animation: pulse-slow 10s ease-in-out infinite;
            background-size: 200% 200%;
          }
          .hide-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
          }
          .hide-scrollbar::-webkit-scrollbar {
            display: none;
          }
          `}
        </style>

        <div className="w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -10, opacity: 0 }}
              transition={{ duration: 0.25 }}
            >
              {isLoading ? (
                <div className="flex justify-center items-center py-20">
                  <Loader className="w-12 h-12 text-cyan-400 animate-spin" />
                </div>
              ) : (
                tabData[activeTab].render()
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Modals for editing */}
      <AnimatePresence>
        {editingMember && (
          <Modal isOpen={!!editingMember} onClose={() => setEditingMember(null)} title="Edit Member">
            <Input
              value={editingMember.name}
              onChange={(e) => setEditingMember({ ...editingMember, name: e.target.value })}
              className="mb-4"
            />
            <PrimaryButton
              onClick={() => {
                crud(`members/${editingMember._id}`, { name: editingMember.name }, "patch");
                setEditingMember(null);
              }}
            >
              Save Changes
            </PrimaryButton>
          </Modal>
        )}
        {editingExpense && (
          <Modal isOpen={!!editingExpense} onClose={() => setEditingExpense(null)} title="Edit Expense">
            <Input
              value={editingExpense.description}
              onChange={(e) => setEditingExpense({ ...editingExpense, description: e.target.value })}
              placeholder="Description"
              className="mb-2"
            />
            <Input
              type="number"
              value={editingExpense.amount}
              onChange={(e) => setEditingExpense({ ...editingExpense, amount: e.target.value })}
              placeholder="Amount"
              className="mb-4"
            />
            <PrimaryButton
              onClick={() => {
                crud(`expenses/${editingExpense._id}`, editingExpense, "patch");
                setEditingExpense(null);
              }}
            >
              Save Changes
            </PrimaryButton>
          </Modal>
        )}
        {editingTask && (
          <Modal isOpen={!!editingTask} onClose={() => setEditingTask(null)} title="Edit Task">
            <Input
              value={editingTask.item}
              onChange={(e) => setEditingTask({ ...editingTask, item: e.target.value })}
              className="mb-4"
            />
            <PrimaryButton
              onClick={() => {
                crud(`checklist/${editingTask._id}`, { item: editingTask.item }, "patch");
                setEditingTask(null);
              }}
            >
              Save Changes
            </PrimaryButton>
          </Modal>
        )}
        {editingPoll && (
          <Modal isOpen={!!editingPoll} onClose={() => setEditingPoll(null)} title="Edit Poll">
            <Input
              value={editingPoll.question}
              onChange={(e) => setEditingPoll({ ...editingPoll, question: e.target.value })}
              className="mb-4"
            />
            <PrimaryButton
              onClick={() => {
                crud(`polls/${editingPoll._id}`, { question: editingPoll.question }, "patch");
                setEditingPoll(null);
              }}
            >
              Save Changes
            </PrimaryButton>
          </Modal>
        )}
        {editingAnnouncement && (
          <Modal isOpen={!!editingAnnouncement} onClose={() => setEditingAnnouncement(null)} title="Edit Announcement">
            <Input
              value={editingAnnouncement.text}
              onChange={(e) => setEditingAnnouncement({ ...editingAnnouncement, text: e.target.value })}
              className="mb-4"
            />
            <PrimaryButton
              onClick={() => {
                crud(`announcements/${editingAnnouncement._id}`, { text: editingAnnouncement.text }, "patch");
                setEditingAnnouncement(null);
              }}
            >
              Save Changes
            </PrimaryButton>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  );

  // ----------------- RENDER FUNCTIONS -----------------
  function renderMembers() {
    return (
      <SectionCard>
        <h2 className="text-3xl font-bold mb-6 text-cyan-400">Members</h2>
        <div className="flex flex-col md:flex-row gap-2 mb-6">
          <Input
            value={newMember}
            onChange={(e) => setNewMember(e.target.value)}
            placeholder="New member name"
          />
          <PrimaryButton
            onClick={() => { crud("members", { name: newMember, userId }); setNewMember(''); }}
            disabled={newMember.trim() === ""}
          >
            <Plus className="inline w-5 h-5 mr-2" /> Add Member
          </PrimaryButton>
        </div>
        {!isAppReady && (
          <p className="text-center text-red-400 mb-4">
            Add at least 2 members to enable other features.
          </p>
        )}
        <div className="flex flex-col gap-3">
          {members.length === 0 ? (
            <div className="text-center text-gray-500 py-8">No members have been added yet.</div>
          ) : (
            members.map((m) => (
              <motion.div
                key={m._id || m.name}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="flex items-center gap-4 bg-gray-800/40 rounded-xl px-4 py-3 shadow-inner border-2 border-gray-700/60 transition-all duration-300 hover:border-cyan-500/50"
              >
                <div className="w-10 h-10 rounded-full bg-cyan-600 flex items-center justify-center font-bold text-lg text-white">
                  {getInitials(m.name)}
                </div>
                <span className="flex-1 text-white">{m.name}</span>
                <div className="flex gap-1">
                  <IconButton icon={Edit2} onClick={() => setEditingMember(m)} />
                  <IconButton icon={Trash2} onClick={() => crud(`members/${m._id}`, { id: m._id }, "delete")} />
                </div>
              </motion.div>
            ))
          )}
        </div>
      </SectionCard>
    );
  }

  function renderExpenses() {
    const totalAmount = expenses.reduce((sum, e) => sum + parseFloat(e.amount || 0), 0);
    return (
      <SectionCard>
        <h2 className="text-3xl font-bold mb-6 text-cyan-400">Expenses</h2>
        <div className="flex flex-col md:flex-row gap-2 mb-6">
          <Input value={newExpense.description} onChange={(e) => setNewExpense({ ...newExpense, description: e.target.value })} placeholder="Description" />
          <Input
            type="number"
            value={newExpense.amount}
            onChange={(e) => {
              const amount = e.target.value;
              if (amount === "" || (amount > 0)) {
                setNewExpense({ ...newExpense, amount });
              }
            }}
            placeholder="Amount (₹)"
          />
          <PrimaryButton
            onClick={() => { crud("expenses", newExpense, "post"); setNewExpense({ description: "", amount: "" }); }}
            disabled={newExpense.description.trim() === "" || newExpense.amount <= 0}
          >
            <Plus className="inline w-5 h-5 mr-2" /> Add Expense
          </PrimaryButton>
        </div>
        <div className="bg-gray-800/40 rounded-2xl p-4 text-center mb-6 border-2 border-gray-700/60 shadow-inner shadow-black/30">
          <div className="text-lg text-gray-400">Total Expenses:</div>
          <div className="text-4xl font-extrabold text-cyan-400 drop-shadow-lg drop-shadow-cyan-400/50">₹{totalAmount.toFixed(2)}</div>
        </div>
        <div className="flex flex-col gap-3">
          {expenses.length === 0 ? (
            <div className="text-center text-gray-500 py-8">No expenses have been added yet.</div>
          ) : (
            expenses.map((e) => (
              <motion.div
                key={e._id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="flex items-center justify-between gap-4 bg-gray-800/40 rounded-xl px-4 py-3 shadow-inner border-2 border-gray-700/60 transition-all duration-300 hover:border-cyan-500/50"
              >
                <div className="flex-1">
                  <div className="font-semibold text-white">{e.description}</div>
                  <div className="text-gray-400 text-sm">₹{parseFloat(e.amount).toFixed(2)}</div>
                </div>
                <div className="flex gap-1">
                  <IconButton icon={Edit2} onClick={() => setEditingExpense(e)} />
                  <IconButton icon={Trash2} onClick={() => crud(`expenses/${e._id}`, { id: e._id }, "delete")} />
                </div>
              </motion.div>
            ))
          )}
        </div>
      </SectionCard>
    );
  }

  function renderChecklist() {
    return (
      <SectionCard>
        <h2 className="text-3xl font-bold mb-6 text-cyan-400">Checklist</h2>
        <div className="flex flex-col md:flex-row gap-2 mb-6">
          <Input value={newTask} onChange={(e) => setNewTask(e.target.value)} placeholder="New Task" />
          <PrimaryButton
            onClick={() => { crud("checklist", { item: newTask, completed: false }, "post"); setNewTask(""); }}
            disabled={newTask.trim() === ""}
          >
            <Plus className="inline w-5 h-5 mr-2" /> Add Task
          </PrimaryButton>
        </div>
        <div className="mb-6 flex justify-center">
           <OutlineButton onClick={handleGenerateChecklist} disabled={isGenerating}>
            {isGenerating ? <Loader className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5 mr-2" />}
            {isGenerating ? "Generating..." : "Suggest Tasks"}
          </OutlineButton>
        </div>
        <div className="flex flex-col gap-3">
          {checklist.length === 0 ? (
            <div className="text-center text-gray-500 py-8">No tasks have been added yet.</div>
          ) : (
            checklist.map((t) => (
              <motion.div
                key={t._id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className={`flex items-center justify-between gap-4 bg-gray-800/40 rounded-xl px-4 py-3 shadow-inner border-2 border-gray-700/60 transition-all duration-300 hover:border-cyan-500/50 ${t.completed ? 'opacity-50 line-through' : ''}`}
              >
                <span className="flex-1 text-white">{t.item}</span>
                <div className="flex gap-1">
                  <IconButton icon={Check} onClick={() => handleCompleteTask(t._id, !t.completed)} className={t.completed ? 'text-green-400' : ''}/>
                  <IconButton icon={Edit2} onClick={() => setEditingTask(t)} />
                  <IconButton icon={Trash2} onClick={() => crud(`checklist/${t._id}`, { id: t._id }, "delete")} />
                </div>
              </motion.div>
            ))
          )}
        </div>
      </SectionCard>
    );
  }

  function renderPolls() {
    const handleAddOption = () => {
      setNewPoll({ ...newPoll, options: [...newPoll.options, { text: "" }] });
    };

    const handleRemoveOption = (index) => {
      setNewPoll({ ...newPoll, options: newPoll.options.filter((_, i) => i !== index) });
    };

    const handleOptionChange = (index, text) => {
      const updatedOptions = newPoll.options.map((opt, i) =>
        i === index ? { ...opt, text } : opt
      );
      setNewPoll({ ...newPoll, options: updatedOptions });
    };
    
    return (
      <SectionCard>
        <h2 className="text-3xl font-bold mb-6 text-cyan-400">Polls</h2>
        <div className="flex flex-col gap-4 mb-6">
          <Input
            value={newPoll.question}
            onChange={(e) => setNewPoll({ ...newPoll, question: e.target.value })}
            placeholder="Poll Question"
          />
          <div className="flex flex-col gap-2">
            {newPoll.options.map((option, index) => (
              <div key={index} className="flex gap-2 items-center">
                <Input
                  value={option.text}
                  onChange={(e) => handleOptionChange(index, e.target.value)}
                  placeholder={`Option ${index + 1}`}
                />
                {newPoll.options.length > 2 && (
                  <IconButton icon={X} onClick={() => handleRemoveOption(index)} />
                )}
              </div>
            ))}
          </div>
          <OutlineButton onClick={handleAddOption}>
            <Plus className="inline w-5 h-5 mr-2" /> Add Option
          </OutlineButton>
          <PrimaryButton
            onClick={() => {
              crud("polls", newPoll, "post");
              setNewPoll({ question: "", options: [{ text: "" }, { text: "" }] });
            }}
            disabled={newPoll.question.trim() === "" || newPoll.options.some(opt => opt.text.trim() === "")}
          >
            <Plus className="inline w-5 h-5 mr-2" /> Create Poll
          </PrimaryButton>
        </div>
        <div className="flex flex-col gap-3">
          {polls.length === 0 ? (
            <div className="text-center text-gray-500 py-8">No polls have been added yet.</div>
          ) : (
            polls.map((p) => {
              const userVote = p.votedUserIds?.find(v => v.userId === userId);
              const hasVoted = !!userVote;

              return (
                <motion.div
                  key={p._id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.2 }}
                  className="bg-gray-800/40 rounded-xl p-4 shadow-inner border-2 border-gray-700/60 transition-all duration-300 hover:border-cyan-500/50 flex flex-col gap-3"
                >
                  <div className="font-semibold text-white">{p.question}</div>
                  <div className="flex flex-col gap-2">
                    {p.options.map((option, index) => {
                      const voteCount = option.votes || 0;
                      const totalVotes = p.options.reduce((sum, opt) => sum + (opt.votes || 0), 0);
                      const votePercentage = totalVotes > 0 ? (voteCount / totalVotes) * 100 : 0;
                      const isUserVote = userVote && userVote.optionIndex === index;
                      const voters = p.votedUserIds
                        ?.filter(v => v.optionIndex === index)
                        .map(v => members.find(m => m._id === v.userId)?.name || "Unknown");

                      return (
                        <div key={index} className="relative w-full rounded-full bg-gray-700/50 overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${votePercentage}%` }}
                            transition={{ duration: 0.5 }}
                            className="h-full bg-gradient-to-r from-cyan-600/50 to-fuchsia-600/50"
                          />
                          <div className="absolute inset-0 flex items-center justify-between px-4 py-2">
                            <span className="text-white text-sm font-medium drop-shadow-lg drop-shadow-black/50">{option.text}</span>
                            <div className="flex items-center gap-2">
                              {isUserVote && <Check className="w-4 h-4 text-white" />}
                              <span className="text-sm text-gray-300">{voteCount} votes ({votePercentage.toFixed(0)}%)</span>
                            </div>
                          </div>
                          {voters && voters.length > 0 && (
                            <div className="absolute top-full left-0 mt-1 text-xs text-gray-400 animate-fade-in-up transition-opacity duration-300">
                              Voters: {voters.join(', ')}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex justify-between items-center text-sm text-gray-400 mt-2">
                    <div className="flex gap-1">
                      {p.options.map((option, index) => (
                        <OutlineButton
                          key={index}
                          onClick={() => handleVote(p._id, index)}
                          disabled={hasVoted}
                          className={`px-3 py-1 text-xs ${userVote?.optionIndex === index ? 'bg-cyan-400 text-gray-900' : ''}`}
                        >
                          Vote for "{option.text}"
                        </OutlineButton>
                      ))}
                    </div>
                    <div className="flex gap-1">
                      <IconButton icon={Edit2} onClick={() => setEditingPoll(p)} />
                      <IconButton icon={Trash2} onClick={() => crud(`polls/${p._id}`, { id: p._id }, "delete")} />
                    </div>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </SectionCard>
    );
  }

  function renderAnnouncements() {
    return (
      <SectionCard>
        <h2 className="text-3xl font-bold mb-6 text-cyan-400">Announcements</h2>
        <div className="flex flex-col md:flex-row gap-2 mb-6">
          <Input value={newAnnouncement} onChange={(e) => setNewAnnouncement(e.target.value)} placeholder="New Announcement" />
          <PrimaryButton
            onClick={() => { crud("announcements", { text: newAnnouncement }, "post"); setNewAnnouncement(""); }}
            disabled={newAnnouncement.trim() === ""}
          >
            <Plus className="inline w-5 h-5 mr-2" /> Add
          </PrimaryButton>
        </div>
        <div className="mb-6 flex justify-center">
          <OutlineButton onClick={handleDraftAnnouncement} disabled={isGenerating}>
            {isGenerating ? <Loader className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5 mr-2" />}
            {isGenerating ? "Drafting..." : "Draft Announcement"}
          </OutlineButton>
        </div>
        <div className="flex flex-col gap-3">
          {announcements.length === 0 ? (
            <div className="text-center text-gray-500 py-8">No announcements have been made yet.</div>
          ) : (
            announcements.map((a) => (
              <motion.div
                key={a._id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="bg-gray-800/40 rounded-xl p-4 shadow-inner border-2 border-gray-700/60 transition-all duration-300 hover:border-cyan-500/50 flex flex-col gap-3"
              >
                <div className="text-white whitespace-pre-wrap">{a.text}</div>
                <div className="flex justify-end gap-1">
                  <IconButton icon={Edit2} onClick={() => setEditingAnnouncement(a)} />
                  <IconButton icon={Trash2} onClick={() => crud(`announcements/${a._id}`, { id: a._id }, "delete")} />
                </div>
              </motion.div>
            ))
          )}
        </div>
      </SectionCard>
    );
  }
}
