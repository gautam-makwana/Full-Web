// src/api/axios.js
import axios from "axios";

// Base URL from environment or fallback
const BASE_URL =
  import.meta.env.VITE_API_BASE?.replace(/\/+$/, "") || "http://localhost:8080/";

// Axios instance
const api = axios.create({
  baseURL: BASE_URL,
  timeout: 20000, // longer timeout in case of slow connections
  headers: {
    "Content-Type": "application/json",
  },
});

// Attach token before each request
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("tm_token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Global response handler
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      // Handle known error codes
      if (error.response.status === 401) {
        console.warn("Unauthorized - logging out user");
        localStorage.removeItem("tm_token");
        localStorage.removeItem("tm_user");
        // Optional: redirect to login
        if (window.location.pathname !== "/login") {
          window.location.href = "/login";
        }
      }
    } else {
      // Network / CORS / timeout errors
      console.error("API Error:", error.message || error);
    }
    return Promise.reject(error);
  }
);

export default api;
