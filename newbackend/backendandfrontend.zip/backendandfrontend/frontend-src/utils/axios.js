// frontend/src/utils/axios.js
import axios from "axios";

const BASE = import.meta.env.VITE_API_BASE || "http://localhost:8080/api";

const api = axios.create({
  baseURL: BASE,
  timeout: 15000,
});

// ✅ Add token automatically
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("tm_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// ✅ Handle errors globally (optional)
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      // Token expired → logout user
      localStorage.removeItem("tm_token");
      window.location.href = "/login";
    }
    return Promise.reject(err);
  }
);

export default api;
