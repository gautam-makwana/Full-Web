// frontend/src/App.jsx
import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import Home from "./pages/Home";
import TravelType from "./pages/TravelType";
import MoodSelection from "./pages/MoodSelection";
import Results from "./pages/Results";
import Login from "./pages/Login";
import Register from "./pages/Register";
import TripPlanner from "./pages/TripPlanner";
import TripSummary from "./pages/TripSummary";
import TripJournal from "./pages/TripJournal";
import GroupToolsWrapper from "./pages/GroupToolsWrapper";

// Advanced features
import TravelMediumSuggestionsPage from "./pages/TravelMediumSuggestions";
import SmartPackingSuggestionsPage from "./pages/SmartPackingSuggestions";
import NearbyRecommendationsPage from "./pages/NearbyRecommendations";
import CurrencyConverterPage from "./pages/CurrencyConverter";
import LanguageTranslatorPage from "./pages/LanguageTranslator";
import AIChatbotForLocalAssistancePage from "./pages/AIChatbotForLocalAssistance";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/travel-type" element={<TravelType />} />
      <Route path="/mood" element={<MoodSelection />} />
      <Route path="/results" element={<Results />} />
      <Route path="/trip-planner" element={<TripPlanner />} />
      <Route path="/trip-summary" element={<TripSummary />} />
      <Route path="/trip-journal" element={<TripJournal />} />
      <Route path="/group-tools" element={<GroupToolsWrapper />} />

      {/* Advanced tools */}
      <Route path="/travel-medium-suggestions" element={<TravelMediumSuggestionsPage />} />
      <Route path="/smart-packing-suggestions" element={<SmartPackingSuggestionsPage />} />
      <Route path="/nearby-recommendations" element={<NearbyRecommendationsPage />} />
      <Route path="/currency-converter" element={<CurrencyConverterPage />} />
      <Route path="/language-translator" element={<LanguageTranslatorPage />} />
      <Route path="/ai-chatbot" element={<AIChatbotForLocalAssistancePage />} />

      {/* Redirect unknown */}
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}
