/* eslint-disable react-refresh/only-export-components */
import { createContext, useContext, useState } from "react";

const TripContext = createContext();

export const TripProvider = ({ children }) => {
  const [tripPlanned, setTripPlanned] = useState(false);
  const [tripData, setTripData] = useState(null);

  // user from tripData
  const user = tripData?.user || null;
  const tripId = tripData?._id || null;

  return (
    <TripContext.Provider
      value={{
        tripPlanned,
        setTripPlanned,
        tripData,
        setTripData,
        user,
        tripId,
      }}
    >
      {children}
    </TripContext.Provider>
  );
};

export const useTripContext = () => useContext(TripContext);
