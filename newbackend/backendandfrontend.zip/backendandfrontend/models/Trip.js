const mongoose = require("mongoose");

const tripSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    destination: {
      name: String,
      coords: {
        lat: Number,
        lon: Number,
      },
    },
    mood: String,
    date: Date,
    duration: String,
    budget: Number,
    travelType: String,
    origin: {
      name: String,
      code: String,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Trip", tripSchema);
